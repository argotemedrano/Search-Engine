[](tests/engine/page1.md) [this should still be valid 
(text) (and no link ) should))(be generated))](tests/engine/page4.txt)
[LINK DOes Not EXiSt](doesnt-exist.md) [     ]

[empty URL]()